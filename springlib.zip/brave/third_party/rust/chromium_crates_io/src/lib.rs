// Copyright 2023 The Chromium Authors
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

// The root of an empty crate that is used for running Cargo against the
// dependencies used by Chromium.
